"""Assemble and audit the approved artwork-only handoff in this review folder.

Run after committing the website and app Store changes. Does not build, alter or
package any PBW, publish anything, or modify the frozen previous review folder.
"""
from pathlib import Path
import base64
import hashlib
import json
import shutil
import struct
import subprocess
import xml.etree.ElementTree as ET
import zipfile

REVIEW = Path(__file__).resolve().parent
WATCH = REVIEW.parent
SITE = WATCH.parent / "XOCE-website-update"
PREVIOUS = WATCH / "Store-Update-2026-11-14"
BASE_SITE = "69016e5fa1883b9a863c04a5612387907ee49ec8"
ZIP_NAME = "XOCE-tactile-artwork-2026-11-14.zip"
PRODUCTS = json.loads((PREVIOUS / "inputs/products.json").read_text())
BASE_STORE = json.loads((PREVIOUS / "inputs/store-commits.json").read_text())
STORE_COMMITS = json.loads((REVIEW / "store-commits.json").read_text())
SLUGS = dict(zip([p["repo"] for p in PRODUCTS], [
    "dynamic", "halftone", "timer", "dashboard", "open-activity", "chmu-weather"
]))
OLD_ARCHIVES = {
    "XOCE-latest-PBWs-2026-11-14.zip": "5eed3f1260fdfe90076534b7656ce3e4d7e71f3124d669aff226b4c3be1c5dd7",
    "XOCE-store-update-2026-11-14.zip": "12aa16bc90a21a15ba3d59adb9b3ace94badd25d6cddd6f69e1d0b458d3bbdb7",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def copy(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert source.read_bytes() == destination.read_bytes(), destination


def png_size(data):
    assert data[:8] == b"\x89PNG\r\n\x1a\n"
    return list(struct.unpack_from(">II", data, 16))


def project_data(text):
    return json.JSONDecoder().raw_decode(text.split("export const projects: Project[] = ", 1)[1])[0]


assert not git(SITE, "status", "--porcelain"), "Commit the checked website first."
site_commit = git(SITE, "rev-parse", "HEAD")
original_projects = {p["slug"]: p for p in project_data(git(SITE, "show", BASE_SITE + ":src/data/projects.ts"))}
current_projects = {p["slug"]: p for p in project_data((SITE / "src/data/projects.ts").read_text())}
assert current_projects.keys() == original_projects.keys()
for slug, current in current_projects.items():
    original = original_projects[slug]
    for key in set(original) | set(current):
        if key not in {"description", "image", "storeArtwork"}:
            assert current.get(key) == original.get(key), (slug, key)
assert not git(SITE, "diff", "--name-only", "--diff-filter=MDRT", BASE_SITE, "HEAD", "--", "public/images", "public/fonts"), "Historical assets changed."

audit_products = []
banner_count = 0
icon_count = 0
for product in PRODUCTS:
    repo = WATCH / product["repo"]
    store = repo / "store"
    slug = SLUGS[product["repo"]]
    target = REVIEW / "artwork" / slug
    assert not git(repo, "status", "--porcelain"), product["repo"]
    assert git(repo, "rev-parse", "HEAD") == STORE_COMMITS[product["repo"]]
    changed = git(repo, "diff", "--name-only", BASE_STORE[product["repo"]], "HEAD").splitlines()
    assert changed and all(p.startswith("store/") for p in changed), changed
    allowed = {"store/ARTWORK-LICENSES.txt", "store/README.md", "store/artwork-provenance.json", "store/icon-provenance.json"}
    art = json.loads((store / "artwork-provenance.json").read_text())
    allowed.update("store/" + f for f in art["files"])
    icon_path = store / "icon-provenance.json"
    icons = json.loads(icon_path.read_text()) if product["type"] != "watchface" else None
    if icons:
        allowed.update("store/" + f for f in icons["files"])
    assert set(changed) <= allowed, changed
    pbw = PREVIOUS / product["file"]
    assert digest(pbw.read_bytes()) == product["sha256"], pbw
    assert zipfile.ZipFile(pbw).testzip() is None
    files = dict(art["files"])
    if icons:
        files.update(icons["files"])
    for name, expected in files.items():
        source = store / name
        assert digest(source.read_bytes()) == expected, source
        if name.endswith(".png"):
            expected_size = [720, 320] if "banner" in name else [80, 80] if "80" in name else [144, 144]
            assert png_size(source.read_bytes()) == expected_size, source
        copy(source, target / name)
    for name in ["artwork-provenance.json", "ARTWORK-LICENSES.txt", "README.md"]:
        copy(store / name, target / name)
    if icons:
        copy(icon_path, target / icon_path.name)
        icon_count += 1
    banner_records = {}
    for platform, record in art.get("banners", {}).items():
        banner_count += 1
        screenshot = store / record["screenshot"]
        frame = SITE / "public/images/devices" / record["frame"]
        assert digest(screenshot.read_bytes()) == record["screenshotSha256"]
        assert digest(frame.read_bytes()) == record["frameSha256"]
        svg = ET.fromstring((store / record["file"].replace(".png", ".svg")).read_bytes())
        embedded = []
        for element in svg.iter():
            for value in element.attrib.values():
                if value.startswith("data:image/png;base64,"):
                    embedded.append(digest(base64.b64decode(value.split(",", 1)[1])))
        assert record["screenshotSha256"] in embedded and record["frameSha256"] in embedded, record
        copy(screenshot, REVIEW / "references/native-captures" / slug / screenshot.name)
        copy(frame, REVIEW / "references/device-frames" / frame.name)
        banner_records[platform] = {
            "file": record["file"], "dimensions": [720, 320],
            "device": "Pebble Time 2" if platform == "emery" else "Pebble Round 2",
            "nativeCaptureSha256": record["screenshotSha256"],
            "frameSha256": record["frameSha256"],
            "frameSource": record["frameSource"], "frameCredit": record["frameCredit"],
        }
    save_json(target / "upload-map.json", {
        "product": product["product"], "type": product["type"], "uuid": product["uuid"],
        "representedVersion": product["version"], "sourceCommit": STORE_COMMITS[product["repo"]],
        "purpose": "Artwork fields for the existing listing; no PBW or new version is supplied.",
        "publication": "Local preparation. Match captures to the live release before applying; website launch gates remain in place.",
        "storeBanners": banner_records,
        "storeIcons": {"small": "icon-small-80.png", "large": "icon-large-144.png"} if icons else {},
        "websiteProductMark": "product-mark-144.png",
        "standaloneScreenshots": "Use the existing raw, unframed Store captures from the matching verified app version.",
    })
    audit_products.append({
        "product": product["product"], "repo": product["repo"], "slug": slug,
        "versionUnchanged": product["version"], "uuidUnchanged": product["uuid"],
        "sourceCommit": product["sourceCommit"], "previousStoreCommit": BASE_STORE[product["repo"]],
        "artworkCommit": STORE_COMMITS[product["repo"]], "changedPaths": changed,
        "unchangedPbw": {"file": product["file"], "sha256": product["sha256"], "includedInThisPackage": False},
        "artworkHashAndDimensionsVerified": True, "nativeSourceAndCapturesUnchanged": True,
        "banners": banner_records,
    })
assert banner_count == 10 and icon_count == 4

old_archives = []
for name, expected in OLD_ARCHIVES.items():
    path = PREVIOUS / name
    assert digest(path.read_bytes()) == expected, path
    old_archives.append({"file": str(path.relative_to(WATCH)), "sha256": expected, "unchanged": True})

for source in sorted((SITE / "public/images/identity").iterdir()):
    copy(source, REVIEW / "brand" / source.name)
for source in sorted((SITE / "public/fonts/xoce").iterdir()):
    copy(source, REVIEW / "brand/fonts" / source.name)
copy(SITE / "docs/xoce-visual-identity.json", REVIEW / "brand/xoce-visual-identity.json")
copy(REVIEW / "chmu-weather-website-banner.svg", REVIEW / "brand/chmu-weather-website-banner.svg")
copy(REVIEW / "chmu-weather-website-banner.png", REVIEW / "brand/chmu-weather-website-banner.png")
fonts = json.loads((REVIEW / "brand/fonts/provenance.json").read_text())
for font in fonts["sources"]:
    assert digest((REVIEW / "fonts/source" / font["file"]).read_bytes()) == font["sha256"]
for font in fonts["exports"]:
    assert digest((REVIEW / "brand/fonts" / font["file"]).read_bytes()) == font["sha256"]

browser_dir = SITE / "build/qa/tactile-identity-20261114"
browser = json.loads((browser_dir / "report.json").read_text())
assert browser["passed"] and all(c["passed"] for c in browser["checks"])
assert len(browser["checks"]) == 13 and len(browser["screenshots"]) == 158
for name in ["home-1440-light.png", "home-1440-dark.png", "home-390-first-screen.png", "projects-dynamic-390-light.png", "docs-1440-light.png"]:
    copy(browser_dir / name, REVIEW / "review/website" / name)
copy(browser_dir / "report.json", REVIEW / "verification/website/browser-report.json")
copy(Path("/tmp/xoce-identity-site-test.log"), REVIEW / "verification/website/npm-test.log")
copy(Path("/tmp/xoce-identity-site-check.log"), REVIEW / "verification/website/astro-check.log")
copy(Path("/tmp/xoce-identity-browser.log"), REVIEW / "verification/website/browser.log")
save_json(REVIEW / "verification/runtime-and-assets-audit.json", {
    "passed": True, "date": "2026-11-14", "websiteCommit": site_commit,
    "websiteCatalogueRuntimeAndPublicationUnchanged": True,
    "websiteHistoricalImageAndFontBytesUnchanged": True,
    "allSixAppWorkingTreesClean": True, "products": audit_products,
    "previousArchives": old_archives,
    "counts": {"banners": banner_count, "storeIconSets": icon_count, "productMarks": len(PRODUCTS)},
    "testing": {"website": "npm test passed; follow-up astro check passed after removing an unused binding.",
                "browser": "13 Chromium checks, 158 screenshots; all passed.",
                "apps": "Six app test suites and six Store-kit prepare/check runs passed; logs included.",
                "physicalDevices": "Not run for this artwork-only update."},
})

payload = [REVIEW / "README.md", REVIEW / "store-commits.json"]
payload += sorted(REVIEW.glob("*.py"))
for folder in ["artwork", "brand", "fonts", "references", "review", "verification"]:
    payload += sorted(p for p in (REVIEW / folder).rglob("*") if p.is_file())
assert all(p.suffix.lower() not in {".pbw", ".zip"} for p in payload)
inventory = []
for path in payload:
    data = path.read_bytes()
    record = {"file": path.relative_to(REVIEW).as_posix(), "sha256": digest(data), "bytes": len(data)}
    if path.suffix.lower() == ".png":
        record["dimensions"] = png_size(data)
    inventory.append(record)
save_json(REVIEW / "manifest.json", {
    "schemaVersion": 1, "identity": "XOCE tactile", "date": "2026-11-14",
    "package": ZIP_NAME, "artworkOnly": True, "pbwsIncluded": False,
    "websiteCommit": site_commit, "appArtworkCommits": STORE_COMMITS,
    "counts": {"banners": banner_count, "storeIconSets": icon_count, "websiteProductMarks": len(PRODUCTS)},
    "products": audit_products, "files": inventory,
    "credits": {"type": "Fira Sans / Fira Sans Condensed, SIL OFL 1.1; see fonts/source/OFL.txt.",
                "deviceFrames": "Core Devices; unchanged files and sources recorded per banner.",
                "nativeCaptures": "Original app emulator captures with example data; unchanged PNG bytes."},
    "publication": "Local commits only. No app upload, push or website deployment.",
})
payload.append(REVIEW / "manifest.json")
payload = sorted(set(payload))
(REVIEW / "SHA256SUMS.txt").write_text("".join(f"{digest(p.read_bytes())}  {p.relative_to(REVIEW).as_posix()}\n" for p in payload))
payload.append(REVIEW / "SHA256SUMS.txt")
archive_path = REVIEW / ZIP_NAME
with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(payload):
        info = zipfile.ZipInfo(path.relative_to(REVIEW).as_posix(), date_time=(2026, 11, 14, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert not any(Path(n).suffix.lower() in {".pbw", ".zip"} for n in archive.namelist())
    for line in archive.read("SHA256SUMS.txt").decode().splitlines():
        expected, name = line.split("  ", 1)
        assert digest(archive.read(name)) == expected, name
(REVIEW / "ZIP-SHA256SUMS.txt").write_text(f"{digest(archive_path.read_bytes())}  {ZIP_NAME}\n")
print(json.dumps({"passed": True, "archive": str(archive_path), "files": len(payload),
                  "bytes": archive_path.stat().st_size, "banners": banner_count,
                  "iconSets": icon_count, "websiteCommit": site_commit}, indent=2))
