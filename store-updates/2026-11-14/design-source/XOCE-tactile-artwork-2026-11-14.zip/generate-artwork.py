"""Original tactile XOCE marketing artwork. Native capture and frame bytes remain unchanged."""
from pathlib import Path
import json,subprocess,hashlib,base64,html,sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
ROOT=Path(__file__).resolve().parents[1];REVIEW=Path(__file__).resolve().parent
SITE=ROOT.parent/'XOCE-website-update'
fonts={False:TTFont(REVIEW/'fonts/source/FiraSans-Regular.ttf'),True:TTFont(REVIEW/'fonts/source/FiraSansCondensed-ExtraBold.ttf')}
sha=lambda b:hashlib.sha256(b).hexdigest()
def measure(text,point,bold=False):
 f=fonts[bold];c=f.getBestCmap();return sum(f['hmtx'][c.get(ord(ch),'.notdef')][0]for ch in text)*point/f['head'].unitsPerEm
def text(text,x,y,point,fill,bold=False):
 f=fonts[bold];glyphs=f.getGlyphSet();cmap=f.getBestCmap();scale=point/f['head'].unitsPerEm;parts=[];offset=0
 for ch in text:
  name=cmap.get(ord(ch),'.notdef');pen=SVGPathPen(glyphs);glyphs[name].draw(pen);d=pen.getCommands()
  if d:parts.append(f'<path transform="translate({offset},0)" d="{d}"/>')
  offset+=f['hmtx'][name][0]
 return f'<g aria-label="{html.escape(text)}" fill="{fill}" transform="translate({x},{y}) scale({scale},-{scale})">'+''.join(parts)+'</g>'
def svg(body,w=144,h=144,title=''):
 return f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img"><title>{html.escape(title)}</title>'+body+'</svg>\n'
def glyph(slug,accent):
 common='fill="none" stroke="#edf1ed" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"'
 if slug=='timer':return f'<path {common} d="M43 27H101M43 117H101M48 29V42C48 56 58 62 69 72C58 82 48 89 48 103V115H96V103C96 89 86 82 75 72C86 62 96 56 96 42V29"/><path fill="{accent}" d="M55 103C55 94 65 87 72 80C79 87 89 94 89 103V109H55ZM56 40H88L72 57Z"/>'
 if slug=='dashboard':return f'<rect x="27" y="27" width="90" height="90" rx="13" {common}/><path {common} d="M72 29V115M29 72H115"/><rect x="39" y="39" width="22" height="22" rx="5" fill="{accent}"/><path {common} d="M85 45H103M85 55H97M39 87H59M39 98H52M85 87H103M85 98H97"/>'
 if slug=='open-activity':return f'<path fill="{accent}" stroke="{accent}" stroke-width="5" stroke-linejoin="round" d="M28 58H80V35L116 72L80 109V86H28Z"/><path {common} d="M28 38V28H55M28 106V116H55"/>'
 if slug=='chmu-weather':return f'<g stroke="#ffd369" stroke-width="4" stroke-linecap="round"><path d="M49 23V29M26 46H32M31 29L36 34M67 29L63 34"/></g><circle cx="49" cy="46" r="14" fill="#ffd369"/><path d="M39 98C27 98 20 89 20 78C20 67 28 59 39 58C43 44 55 35 69 35C86 35 99 47 101 62C114 64 122 71 122 82C122 93 113 101 101 101H39Z" fill="#edf1ed"/><path d="M49 113L44 123M73 113L68 123M97 113L92 123" stroke="{accent}" stroke-width="5" stroke-linecap="round"/>'
 if slug=='halftone':
  import math
  return ''.join(f'<circle cx="{72+49*math.cos(n*math.pi/12):.2f}" cy="{72+49*math.sin(n*math.pi/12):.2f}" r="3.8" fill="{accent}"/>'for n in range(24))+text('12',38,89,43,'#edf1ed',True)
 return f'<rect x="24" y="26" width="96" height="92" rx="18" fill="none" stroke="#edf1ed" stroke-width="5"/>'+text('13',41,76,39,'#edf1ed',True)+''.join(f'<rect x="{x}" y="{y}" width="12" height="7" rx="3" fill="{accent}"/>'for x in[48,83]for y in[88,102])

PRODUCTS=[
 ('dynamic','pebble-watchface-dynamic','Dynamic','#55aaff',['A clock that makes room.']),
 ('halftone','pebble-watchface-halftone','Halftone','#ff8500',['A bold clock.','A border with depth.']),
 ('timer','pebble-app-timer','Timer','#55aaff',['Set it. Keep it ready.']),
 ('dashboard','pebble-app-dashboard','Dashboard','#79bce6',['Your overview,','one button away.']),
 ('open-activity','pebble-app-open-activity','Open Activity','#b6a2ed',['Back to the app,','with a button.']),
 ('chmu-weather','pebble-chmu-weather','ČHMÚ Weather','#8bc6ef',['Czech weather,','in the Pebble app.'])]
licence=(REVIEW/'fonts/source/OFL.txt').read_text()
credits='''Original XOCE composition, product symbols and Fira text outlines, prepared for Xef.
App repository licensing and third-party notices remain authoritative.
Native emulator screenshots have synthetic example data; embedded PNG bytes are unchanged.
Official Time 2 and Round 2 frame illustrations are credited to Core Devices.
Source: https://apps.repebble.com/images/screenshot_slider_background_emery_v2.png
Source: https://apps.repebble.com/images/screenshot_slider_background_gabbro.png
Frames retain their original bytes, composed only inside marketing banners.
No additional third-party licence is granted by this local artwork preparation.
Fira Sans and Fira Sans Condensed are licensed under SIL OFL 1.1:
'''+licence

def embed(path,x,y,w,h,clip=''):
 return f'<image x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="none" '+(f'clip-path="url(#{clip})" 'if clip else'')+f'xlink:href="data:image/png;base64,{base64.b64encode(path.read_bytes()).decode()}"/>'

def banner_base(name,lines):
 wordmark=(SITE/'public/images/identity/xoce-wordmark.svg').read_text().replace('<svg ', '<svg x="32" y="27" width="86" height="27" ',1)
 body='<defs><linearGradient id="plate" x2=".8" y2="1"><stop stop-color="#3c4953"/><stop offset="1" stop-color="#1c252c"/></linearGradient></defs>'
 body+='<rect width="720" height="320" fill="#e8edf0"/>'+wordmark
 body+=text(name,32,135,62 if name!='ČHMÚ Weather'else 51,'#172127',True)
 for i,line in enumerate(lines):
  assert measure(line,27)<=360,(name,line)
  body+=text(line,32,190+i*35,27,'#344853')
 body+='<rect x="414" y="12" width="294" height="296" rx="22" fill="url(#plate)" stroke="#70818c"/><rect x="415" y="13" width="292" height="294" rx="21" fill="none" stroke="#ffffff" stroke-opacity=".10"/>'
 body+='<defs><clipPath id="stage"><rect x="415" y="13" width="292" height="294" rx="21"/></clipPath></defs>'
 return body

for slug,repo,name,accent,lines in PRODUCTS:
 store=ROOT/repo/'store';listing=json.loads((store/'listing.json').read_text());files={}
 def write(name,data):
  data=data.encode()if isinstance(data,str)else data;(store/name).write_bytes(data);files[name]=sha(data)
 def render(source,dest,width=None):
  args=['rsvg-convert',str(store/source),'-o',str(store/dest)]
  if width:args.extend(['-w',str(width),'-h',str(width)])
  subprocess.run(args,check=True);files[dest]=sha((store/dest).read_bytes())
 # Material edges surround bold, recognizable symbols; the symbol remains clear at 80px.
 plate='<defs><linearGradient id="face" x2="0" y2="1"><stop stop-color="#3c4953"/><stop offset="1" stop-color="#1c252c"/></linearGradient></defs><rect x="1" y="1" width="142" height="142" rx="28" fill="url(#face)" stroke="#0c171e" stroke-width="2"/><rect x="3" y="3" width="138" height="138" rx="26" fill="none" stroke="#dce9f3" stroke-opacity=".22"/>'
 mark=svg(plate+glyph(slug,accent),title=name+' · XOCE tactile product mark')
 write('product-mark.svg',mark);render('product-mark.svg','product-mark-144.png')
 if listing['type']!='watchface':
  write('icon-source.svg',mark);render('icon-source.svg','icon-large-144.png');render('icon-source.svg','icon-small-80.png',80)
  (store/'icon-provenance.json').write_text(json.dumps({'schemaVersion':1,'originalArtwork':True,'family':'XOCE tactile 2026-11-14','files':{n:files[n]for n in ['icon-source.svg','icon-small-80.png','icon-large-144.png']}},indent=2)+'\n')
 banners={}
 if listing['type']!='plugin':
  for platform,names in listing['screenshots'].items():
   screenname=next((n for n in names if 'four-split'in n),names[0]);screen=store/screenname
   frame=SITE/'public/images/devices'/('pebble-time-2.png'if platform=='emery'else'pebble-round-2.png')
   body=banner_base(name,lines)
   fw=274 if platform=='emery'else 282;fh=fw*700/(488 if platform=='emery'else 502);fx=561-fw/2;fy=-44
   if platform=='emery':
    sx=fx+fw*.20287;sy=fy+fh*.26857;sw=fw*.57582;sh=fh*.48286
    nh=sw*228/200
    clip=f'<rect x="{sx}" y="{sy}" width="{sw}" height="{sh}" rx="19"/>'
    screenbody=f'<rect x="{sx}" y="{sy}" width="{sw}" height="{sh}" fill="#000"/>'+embed(screen,sx,sy+(sh-nh)/2,sw,nh,'screen')
   else:
    sx=fx+fw*83/502;sy=fy+fh*182/700;sw=fw*337/502
    clip=f'<circle cx="{sx+sw/2}" cy="{sy+sw/2}" r="{sw/2}"/>'
    screenbody=embed(screen,sx,sy,sw,sw,'screen')
   body+=f'<defs><clipPath id="screen">{clip}</clipPath></defs><g clip-path="url(#stage)">'+screenbody+embed(frame,fx,fy,fw,fh)+'</g>'
   filename=platform+'-family-banner.png';source=filename.replace('.png','.svg');write(source,svg(body,720,320,name+' · '+platform+' native emulator composite'));render(source,filename)
   banners[platform]={'file':filename,'platform':platform,'screenshot':screenname,'screenshotSha256':sha(screen.read_bytes()),'frame':frame.name,'frameSha256':sha(frame.read_bytes()),'frameSource':'https://apps.repebble.com/images/'+('screenshot_slider_background_emery_v2.png'if platform=='emery'else'screenshot_slider_background_gabbro.png'),'frameCredit':'Core Devices','composition':'Front view with strap cropping; complete native screen retained at original aspect ratio.'}
  listing['banners']={p:v['file']for p,v in banners.items()}
 else:
  body=banner_base(name,lines)+embed(store/'product-mark-144.png',467,64,188,188)
  svgfile=REVIEW/'chmu-weather-website-banner.svg';svgfile.write_text(svg(body,720,320,name+' · phone plugin · website-only artwork'))
  subprocess.run(['rsvg-convert',str(svgfile),'-o',str(svgfile.with_suffix('.png'))],check=True)
 (store/'ARTWORK-LICENSES.txt').write_text(credits)
 (store/'artwork-provenance.json').write_text(json.dumps({'schemaVersion':1,'originalArtwork':True,'family':'XOCE tactile 2026-11-14','scope':'Original composition, outlined type and product symbols. Marketing embeds unchanged native screenshots and unchanged official frame bytes. Standalone Store screenshots remain raw and unframed.','font':{'name':'Fira Sans / Fira Sans Condensed','licence':'SIL OFL 1.1','treatment':'Outlined text; full pinned inputs in the identity review folder.'},'files':files,'banners':banners},ensure_ascii=False,indent=2)+'\n')
 (store/'listing.json').write_text(json.dumps(listing,ensure_ascii=False,indent=2)+'\n')
 print(name+' tactile artwork exported',flush=True)
