# XOCE tactile identity — 14 November 2026

The website and artwork implement the homepage concept Xef approved: cool silver, graphite, blue controls, Fira typography, an outlined XOCE wordmark and restrained material depth.

Open the working website at **http://127.0.0.1:4322/xoce/** while its local preview server is running. Actual desktop/mobile browser proof is under `review/website/`. `review/approved-homepage-concept.png` is the original generated design reference, not production UI.

## Artwork package

`XOCE-tactile-artwork-2026-11-14.zip` is an artwork-only update. It contains editable SVGs, PNG exports, upload maps, font inputs/licences, contact sheets and verification. It contains no PBW binaries and does not publish a new app release.

| Folder | Product | Store banners | Store icons |
| --- | --- | --- | --- |
| `artwork/dynamic/` | Dynamic | Emery + Gabbro | None; watchface |
| `artwork/halftone/` | Halftone | Emery + Gabbro | None; watchface |
| `artwork/timer/` | Timer | Emery + Gabbro | 80 + 144 px |
| `artwork/dashboard/` | Dashboard | Emery + Gabbro | 80 + 144 px |
| `artwork/open-activity/` | Open Activity | Emery + Gabbro | 80 + 144 px |
| `artwork/chmu-weather/` | ČHMÚ Weather | None; phone plugin | 80 + 144 px |

Each product’s `upload-map.json` names its files. Banners are 720×320; Emery means Time 2 and Gabbro means Round 2. Upload the PNG exports into the corresponding banner/icon fields. Product marks are website artwork, not additional watchface Store icons. The Weather banner under `brand/` is website-only.

Standalone Store screenshots remain the existing raw, unframed native PNGs. The new banners embed those exact image bytes and the unchanged official device frames. Only the marketing composition crops straps; the whole native screen retains its aspect ratio. `artwork-provenance.json` records the capture/frame hashes, and `ARTWORK-LICENSES.txt` preserves the credits and font licence.

The live Store already shows the prepared version numbers. Artwork preparation does not make those numbers available for another PBW upload. Use the Developer Dashboard’s listing edit for artwork when it matches the live app. New-feature captures and copy must accompany their matching verified release. Existing website launch gates remain in place.

## Website

The Astro implementation uses real components and original project captures. The generated concept is not used as a page image. The identity applies to Home, Software, product pages, About, support, search and Docs, including both themes. Mobile retains the two named watchface previews in its first screen. Documentation keeps a calm reading column.

The wordmark/favicon are in `brand/`. Fira fonts are self-hosted; the exported webfonts, pinned input hashes and unchanged SIL OFL notice are included under `brand/fonts/` and `fonts/source/`. Existing font packages and historical image assets remain available in the repository.

## Verification and reproduction

`verification/` contains the six app test logs and refreshed Store-kit checks, website type/build/reference/launch-test results, Chromium report and runtime/asset identity audit. Browser checks cover desktop/mobile, light/dark, both watch shapes, theme persistence, keyboard, search, reduced effects and no-JavaScript navigation. They also check that Fira typography and the outlined identity load correctly.

`export-fonts.py`, `generate-artwork.py`, `update-website-artwork.py` and `package-artwork.py` are the workspace recipes. They expect this folder under `Watch/`, sibling app/website repositories, Python with fontTools/Pillow, and `rsvg-convert`. The SVGs embed their images and outline their text, so they can be edited independently without installing fonts. The package manifest and `SHA256SUMS.txt` identify the delivered files; `ZIP-SHA256SUMS.txt` checks the outer ZIP.

App runtime source, PBWs and versions are unchanged. Earlier review folders/ZIPs remain intact. All commits are local; no push, app upload or website deployment is part of this work. No new native emulator, physical watch, phone or acoustic testing is claimed for an artwork-only change.
