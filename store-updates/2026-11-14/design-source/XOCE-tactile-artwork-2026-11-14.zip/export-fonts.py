"""Export local, licensed Latin webfonts and the approved typographic XOCE mark."""
from pathlib import Path
import hashlib,json,shutil
from fontTools.ttLib import TTFont
from fontTools import subset
from fontTools.pens.svgPathPen import SVGPathPen
ROOT=Path(__file__).resolve().parent
SITE=ROOT.parents[1]/'XOCE-website-update'
OUT=SITE/'public/fonts/xoce';OUT.mkdir(parents=True,exist_ok=True)
records=[]
for source in sorted((ROOT/'fonts/source').glob('*.ttf')):
 font=TTFont(source);options=subset.Options();options.flavor='woff'
 sub=subset.Subsetter(options=options)
 sub.populate(unicodes=list(range(0x250))+list(range(0x1e00,0x1f00))+list(range(0x2000,0x2070))+list(range(0x20a0,0x20d0))+list(range(0x2190,0x2200))+[0x2212])
 sub.subset(font);font.flavor='woff';font['head'].modified=font['head'].created
 target=OUT/(source.stem+'.woff');font.save(target)
 records.append({'file':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'source':source.name,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'subset':'Latin, Latin Extended, punctuation, currency and arrows; original outlines retained.','licence':'SIL OFL 1.1'})
shutil.copyfile(ROOT/'fonts/source/OFL.txt',OUT/'OFL.txt')
(OUT/'provenance.json').write_text(json.dumps({'family':'Fira Sans / Fira Sans Condensed','delivery':'Self-hosted WOFF with font-display swap; no runtime font service.','sources':json.loads((ROOT/'fonts/source/provenance.json').read_text()),'exports':records},indent=2)+'\n')
font=TTFont(ROOT/'fonts/source/FiraSansCondensed-ExtraBold.ttf');glyphs=font.getGlyphSet();cmap=font.getBestCmap()
def outline(text):
 parts=[];offset=0
 for char in text:
  name=cmap[ord(char)];pen=SVGPathPen(glyphs);glyphs[name].draw(pen)
  parts.append(f'<path transform="translate({offset},0)" d="{pen.getCommands()}"/>');offset+=font['hmtx'][name][0]
 return ''.join(parts),offset
body,width=outline('XOCE');cap=font['OS/2'].sCapHeight
mark=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {cap+12}"><g fill="currentColor" transform="translate(0,{cap}) scale(1,-1)">{body}</g></svg>\n'
art=SITE/'public/images/identity';art.mkdir(parents=True,exist_ok=True);(art/'xoce-wordmark.svg').write_text(mark)
body,width=outline('X')
(art/'favicon.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="20" fill="#006bb6"/><g fill="#fff" transform="translate({(100-width*.085)/2},80) scale(.085,-.085)">{body}</g></svg>\n')
print('Exported five self-hosted webfonts, outlined wordmark and X favicon.')
