"""Append the new artwork without replacing historical website image bytes."""
from pathlib import Path
import json,hashlib,shutil,struct,subprocess
ROOT=Path(__file__).resolve().parents[1];REVIEW=Path(__file__).resolve().parent;SITE=ROOT.parent/'XOCE-website-update'
products=json.loads((ROOT/'Store-Update-2026-11-14/inputs/products.json').read_text());lookup={p['product']:p for p in products}
path=SITE/'src/data/projects.ts';prefix,tail=path.read_text().split('export const projects: Project[] = ',1);projects,end=json.JSONDecoder().raw_decode(tail)
provs={n:json.loads((SITE/n).read_text())for n in ['docs/asset-provenance.json','public/preview-provenance.json']}
def asset(source,destination,p,kind):
 data=source.read_bytes();dest=SITE/'public'/destination.lstrip('/');dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert dest.read_bytes()==data,'Versioned artwork already differs: '+destination
 else:shutil.copyfile(source,dest)
 w,h=struct.unpack_from('>II',data,16)
 entry={'id':Path(destination).stem,'site_path':destination,'capture_version':p['version'],'represented_release':p['version'],'current_release_capture':False,'launch_preview_capture':True,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/p['repo'],text=True).strip(),'source_path':str(source.relative_to(ROOT.parent)),'source_pbw_sha256':p['sha256'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'width':w,'height':h,'evidence_type':kind,'original_artwork':True,'fixture_data':False,'physical_watch_test_evidence':False,'pixel_changes':'Original vector composition; native screenshot/frame bytes embedded unchanged.'}
 for prov in provs.values():
  old=next((x for x in prov['images']if x['site_path']==destination),None)
  if old:assert old['sha256']==entry['sha256'];old.update(entry)
  else:prov['images'].append(entry.copy())
for project in projects:
 if not project.get('publication'):continue
 p=lookup[project['name']];store=ROOT/p['repo']/'store';base='/images/store/'+project['slug']+'-'+p['version']+'-identity-20261114-'
 mark=base+'mark.png';asset(store/'product-mark-144.png',mark,p,'original-xoce-product-mark')
 project['storeArtwork']={'mark':mark,'shareImage':base+('banner-phone.png'if p['type']=='plugin'else'banner-emery.png')}
 if p['type']=='plugin':
  asset(REVIEW/'chmu-weather-website-banner.png',project['storeArtwork']['shareImage'],p,'original-xoce-marketing-artwork');project['image']=mark
 else:
  for platform in ['emery','gabbro']:asset(store/(platform+'-family-banner.png'),base+'banner-'+platform+'.png',p,'original-xoce-marketing-composite')
path.write_text(prefix+'export const projects: Project[] = '+json.dumps(projects,ensure_ascii=False,indent=2)+tail[end:])
for name,prov in provs.items():(SITE/name).write_text(json.dumps(prov,ensure_ascii=False,indent=2)+'\n')
print('Six product artwork bindings updated; historical assets and native screenshots preserved.')
