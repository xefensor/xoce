"""Check actual Store icon pixels against Pebble's tintable-glyph contract."""
from pathlib import Path
import argparse
import json
from PIL import Image


def verify(image, expected_size):
    if image.size != (expected_size, expected_size):
        raise ValueError("Wrong icon dimensions")
    image = image.convert("RGBA")
    pixels = set(image.get_flattened_data())
    if not pixels <= {(0, 0, 0, 0), (0, 0, 0, 255)}:
        raise ValueError("Tintable icons require one black ink colour and binary alpha")
    if pixels != {(0, 0, 0, 0), (0, 0, 0, 255)}:
        raise ValueError("An icon needs both visible glyph pixels and transparent background")
    if any(image.getpixel(point)[3] for point in [(0,0),(image.width-1,0),(0,image.height-1),(image.width-1,image.height-1)]):
        raise ValueError("Icon corners must remain transparent")
    return {"size": expected_size, "ink": "#000000", "alphaValues": [0, 255], "tintable": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    results = []
    for file, size in [("icon-small-80.png", 80), ("icon-large-144.png", 144)]:
        with Image.open(args.folder / file) as image:
            results.append({"file": file, **verify(image, size)})
            for value in [(255, 0, 0, 255), (0, 0, 0, 128), (0, 0, 0, 255)]:
                invalid = image.convert("RGBA")
                invalid.putpixel((0, 0), value)
                try:
                    verify(invalid, size)
                except ValueError:
                    continue
                raise AssertionError("A coloured, antialiased or opaque-corner icon was accepted")
    print(json.dumps({"result": "PASS", "icons": results, "invalidColourAlphaAndBackgroundRejected": True}, indent=2))
