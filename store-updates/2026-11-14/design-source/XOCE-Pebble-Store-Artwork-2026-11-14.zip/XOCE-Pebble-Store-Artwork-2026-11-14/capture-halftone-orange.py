"""Capture the original banner's orange colour scheme from the current PBW."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import struct
import sys
import time
import uuid
import zipfile

REVIEW=Path(__file__).resolve().parent
WATCH=REVIEW.parent
repo=WATCH/'pebble-watchface-halftone'
platform=sys.argv[1]
assert platform in ('emery','gabbro')
out=REVIEW/'verification/native/halftone'/platform
out.mkdir(parents=True,exist_ok=True)
os.environ['PEBBLE_QA_PLATFORM']=platform
os.environ['PEBBLE_QA_STATE']=str(out/('emulator-'+str(time.time_ns())))
sys.path[:0]=[str(WATCH/'recovery-validation'),str(repo/'scripts'),str(WATCH/'pebble-watchface-dynamic/scripts')]
from pipe_emulator import connect
from native_identity import renderer_identity
from pebble_tool.commands.install import ToolAppInstaller
from pebble_tool.commands.emucontrol import send_data_to_qemu
from libpebble2.services.appmessage import AppMessageService,Uint32,ByteArray
from libpebble2.services.screenshot import Screenshot
from libpebble2.protocol.apps import AppRunState,AppRunStateStart
from libpebble2.protocol.system import TimeMessage,SetUTC
from libpebble2.protocol.logs import AppLogMessage,AppLogShippingControl
from libpebble2.communication.transports.qemu.protocol import QemuTimeFormat,QemuBluetoothConnection,QemuContentSize
from PIL import Image

pbw=repo/'releases/Halftone-1.10.2.pbw'
native=out/'native-only.pbw'
with zipfile.ZipFile(pbw)as source,zipfile.ZipFile(native,'w')as target:
    info=json.loads(source.read('appinfo.json'))
    identity=renderer_identity(source.read(platform+'/pebble-app.bin'),source.read(platform+'/app_resources.pbpack'))
    for name in source.namelist():
        if name=='appinfo.json' or name.startswith(platform+'/'):target.writestr(name,source.read(name))
p=connect();app=uuid.UUID(info['uuid']);keys=info['messageKeys']
service=AppMessageService(p);messages=[];receipts={};logs=[]
p.register_endpoint(AppLogMessage,lambda msg:logs.append(str(msg)))
p.send_packet(AppLogShippingControl(enable=True))
service.register_handler('appmessage',lambda tid,target,data:messages.append(data)if target==app else None)
service.register_handler('ack',lambda tid,target:receipts.update({tid:True})if target==app else None)
service.register_handler('nack',lambda tid,target:receipts.update({tid:False})if target==app else None)
sample=int(datetime.datetime(2026,10,31,22,14,tzinfo=datetime.timezone.utc).timestamp())
send_data_to_qemu(p.transport,QemuBluetoothConnection(connected=True))
send_data_to_qemu(p.transport,QemuContentSize(size=1))
p.send_packet(TimeMessage(message=SetUTC(unix_time=sample,utc_offset=0,tz_name='UTC')))
ToolAppInstaller(p,str(native),quiet=True).install()
p.send_packet(AppRunState(data=AppRunStateStart(uuid=app)))
until=time.monotonic()+12;session=None
while not session and time.monotonic()<until:
    session=next((data.get(keys['REQUEST_ACTIVITIES'],data.get(keys['REQUEST_CONTEXT']))for data in reversed(messages)if data.get(keys['REQUEST_ACTIVITIES'],data.get(keys['REQUEST_CONTEXT'],0))>=2),None)
    time.sleep(.04)
assert session,'No native activity session'
spec=importlib.util.spec_from_file_location('capture',repo/'scripts/capture-native-previews.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
plan=module.fixture_plan(session,now=sample-1,mode='complications',names=['two-weather-locations'],sequence=52000)
preset=next(x for x in plan['presets']if x['state']=='idle' and x['theme']=='light')
data={keys[k]:Uint32(v)for k,v in preset['integers'].items()}
data.update({keys[k]:ByteArray(bytes(v))for k,v in preset['bytes'].items()})
data.update({keys['BACKGROUND_COLOR']:Uint32(0xff5500),keys['TEXT_COLOR']:Uint32(0xffffff),keys['ACCENT_COLOR']:Uint32(0xffffff)})
values=[0xff5500,0xffffff,0xffffff,0,0xffffff,0xffffff,24,0,0,0,0,2,0,0,0,0,0]
data[keys['DISPLAY_PREFERENCES']]=ByteArray(bytes([1,17,0,0])+struct.pack('<I',52001)+struct.pack('<17I',*values))
send_data_to_qemu(p.transport,QemuTimeFormat(is_24_hour=True))
tid=service.send_message(app,data);until=time.monotonic()+12
while tid not in receipts and time.monotonic()<until:time.sleep(.03)
assert receipts.pop(tid,None),logs
time.sleep(1.2)
size=(200,228)if platform=='emery'else(260,260)
file=out/'orange.png'
Image.frombytes('RGB',size,b''.join(Screenshot(p).grab_image())).save(file)
assert not any('App fault!'in line for line in logs),logs
(out/'report.json').write_text(json.dumps({'result':'PASS','platform':platform,'version':'1.10.2','candidateSha256':hashlib.sha256(pbw.read_bytes()).hexdigest(),'nativeRendererIdentity':identity,'captures':[{'file':file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'width':size[0],'height':size[1]}],'colourSettings':{'background':'#ff5500','text':'#ffffff','accent':'#ffffff'},'scope':'Fresh Screenshot-service image from the exact current native PBW in SDK 4.44 QEMU. Supported colour settings and synthetic two-location weather data; no phone or physical-device claim.','logs':logs},indent=2)+'\n')
service.shutdown()
print('Captured current orange Halftone',platform,file,flush=True)
