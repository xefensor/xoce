"""Compose contact sheets from the actual exported Store files."""
from pathlib import Path
import base64
import html
import subprocess

ROOT=Path(__file__).resolve().parent
PRODUCTS=[('dynamic','Dynamic'),('halftone','Halftone'),('timer','Timer'),('dashboard','Dashboard'),('open-activity','Open Activity')]


def image(path,x,y,w,h,extra=''):
    return f'<image x="{x}" y="{y}" width="{w}" height="{h}" {extra} href="data:image/png;base64,{base64.b64encode(path.read_bytes()).decode()}"/>'


def save(name,body,width,height):
    source=ROOT/(name+'.svg');source.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}">{body}</svg>')
    subprocess.run(['rsvg-convert',str(source),'-o',str(source.with_suffix('.png'))],check=True)


body='<rect width="1504" height="1884" fill="#fff"/><text x="24" y="36" font-family="sans-serif" font-size="24" font-weight="bold">Store banners · original Halftone direction</text>'
for row,(slug,name)in enumerate(PRODUCTS):
    for column,platform in enumerate(['emery','gabbro']):
        x=24+column*736;y=82+row*360
        body+=f'<text x="{x}" y="{y-10}" font-family="sans-serif" font-size="17">{name} · {"Time 2"if platform=="emery"else"Round 2"}</text>'
        body+=image(ROOT/'products'/slug/(platform+'-family-banner.png'),x,y,720,320)
save('banners-contact-sheet',body,1504,1884)

body='<defs><filter id="white"><feFlood flood-color="white"/><feComposite in2="SourceAlpha" operator="in"/></filter></defs><rect width="960" height="932" fill="#fff"/><rect x="480" width="480" height="932" fill="#111"/>'
for x,ink,name in [(24,'black','LIGHT'),(504,'white','DARK')]:body+=f'<text x="{x}" y="36" fill="{ink}" font-family="sans-serif" font-size="24" font-weight="bold">{name} · same transparent PNG</text>'
for row,(slug,name)in enumerate([('timer','Timer'),('dashboard','Dashboard'),('open-activity','Open Activity'),('chmu-weather','ČHMÚ Weather')]):
    top=64+row*212
    for base,dark in [(0,False),(480,True)]:
        ink='white'if dark else'black';body+=f'<text x="{base+24}" y="{top+24}" fill="{ink}" font-family="sans-serif" font-size="20">{html.escape(name)}</text>'
        for x,y,size,file in [(52,top+64,80,'icon-small-80.png'),(254,top+36,144,'icon-large-144.png')]:
            body+=image(ROOT/'products'/slug/file,base+x,y,size,size,'filter="url(#white)"'if dark else'')
            body+=f'<text x="{base+x+size/2}" y="{top+204}" fill="{ink}" text-anchor="middle" font-family="sans-serif" font-size="15">{size} × {size}</text>'
save('icons-light-dark',body,960,932)
print('Actual banner and light/dark icon contact sheets exported.')
