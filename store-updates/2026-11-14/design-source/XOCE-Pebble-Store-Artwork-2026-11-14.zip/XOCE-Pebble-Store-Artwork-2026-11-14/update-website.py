"""Append the selected banner family and tintable marks without changing history."""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess

REVIEW=Path(__file__).resolve().parent
WATCH=REVIEW.parent
SITE=WATCH.parent/'XOCE-website-update'
products=json.loads((WATCH/'Pebble-Store-Versions-2026-11-14/products.json').read_text())
lookup={p['product']:p for p in products}
file=SITE/'src/data/projects.ts';prefix,tail=file.read_text().split('export const projects: Project[] = ',1);projects,end=json.JSONDecoder().raw_decode(tail)
provs={name:json.loads((SITE/name).read_text())for name in ['docs/asset-provenance.json','public/preview-provenance.json']}
galleries=json.loads((SITE/'src/data/launch-screenshots.json').read_text())


def asset(source,destination,p,kind,extra=None):
    data=source.read_bytes();target=SITE/'public'/destination.lstrip('/')
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert target.read_bytes()==data,'Versioned artwork differs: '+destination
    else:shutil.copyfile(source,target)
    width,height=struct.unpack_from('>II',data,16)
    entry={'id':Path(destination).stem,'site_path':destination,'capture_version':p['version'],'represented_release':p['version'],'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=WATCH/p['repo'],text=True).strip(),'source_path':str(source.relative_to(WATCH.parent)),'source_pbw_sha256':p['sha256'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'width':width,'height':height,'evidence_type':kind,'original_artwork':kind.startswith('original-'),'current_release_capture':False,'launch_preview_capture':True,'fixture_data':kind=='native-emulator-screenshot','physical_watch_test_evidence':False,'pixel_changes':'none'if kind=='native-emulator-screenshot'else'Original composition; native PNG bytes embedded unchanged.'}
    if extra:entry.update(extra)
    for prov in provs.values():
        existing=next((x for x in prov['images']if x['site_path']==destination),None)
        if existing:assert existing['sha256']==entry['sha256'];existing.update(entry)
        else:prov['images'].append(entry.copy())
    return entry


for project in projects:
    if not project.get('publication'):continue
    p=lookup[project['name']];store=WATCH/p['repo']/'store';slug=project['slug'];base='/images/store/'+slug+'-'+p['version']+'-pebble-20261114-'
    mark=base+'mark.png';asset(store/'product-mark-144.png',mark,p,'original-xoce-product-mark',{'transparent_monochrome_glyph':True})
    project['storeArtwork']={'mark':mark,'shareImage':base+('banner-phone.png'if p['type']=='plugin'else'banner-emery.png')}
    if p['type']=='plugin':
        asset(REVIEW/'products'/slug/'website-banner.png',project['storeArtwork']['shareImage'],p,'original-xoce-marketing-artwork');project['image']=mark
    else:
        for platform in ['emery','gabbro']:asset(store/(platform+'-family-banner.png'),base+'banner-'+platform+'.png',p,'original-xoce-marketing-composite')
    if slug=='halftone':
        for platform in ['emery','gabbro']:
            source=store/(platform+'-store-20261114-orange.png');destination='/images/screenshots/halftone-'+p['version']+'-20261114-'+platform+'-orange.png'
            record=asset(source,destination,p,'native-emulator-screenshot',{'scope':'Fresh SDK 4.44 Screenshot-service capture from the exact reviewed PBW; supported orange palette and synthetic weather locations.'})
            if not any(x['image']==destination for x in galleries[slug]):
                galleries[slug].append({'image':destination,'title':'Original orange palette','caption':'Current native emulator capture with orange colours and two weather locations; example data.','alt':'Halftone '+p['version']+' on '+('Time 2'if platform=='emery'else'Round 2')+' in its orange palette.','kind':'watch','version':p['version'],'width':record['width'],'height':record['height'],'source':'/preview-provenance.json','platform':platform})

file.write_text(prefix+'export const projects: Project[] = '+json.dumps(projects,ensure_ascii=False,indent=2)+tail[end:])
(SITE/'src/data/launch-screenshots.json').write_text(json.dumps(galleries,ensure_ascii=False,indent=2)+'\n')
for name,data in provs.items():(SITE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Six product marks/social images updated; historical images preserved and two current orange native captures appended.')
