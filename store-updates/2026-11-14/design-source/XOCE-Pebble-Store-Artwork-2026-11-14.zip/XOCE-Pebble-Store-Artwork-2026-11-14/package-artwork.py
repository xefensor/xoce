"""Package selected artwork sources and actual verification, excluding experiments."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
WATCH = ROOT.parent
SITE = WATCH.parent / "XOCE-website-update"
OUT = ROOT / "selected-artwork"
assert not OUT.exists(), "Preserve an existing source package; do not silently mix generations."


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert source.read_bytes() == target.read_bytes()


for source in (ROOT / "products").rglob("*"):
    if source.is_file():
        copy(source, OUT / source.relative_to(ROOT))
for source in (ROOT / "reference").iterdir():
    copy(source, OUT / source.relative_to(ROOT))
for source in (ROOT / "verification").rglob("*"):
    if source.is_file() and source.suffix in {".json", ".png", ".log"} and not any(p.startswith("emulator-") for p in source.parts):
        copy(source, OUT / source.relative_to(ROOT))
for name in ["FiraSansCondensed-Bold.ttf", "OFL-FiraSans.txt"]:
    copy(WATCH / "pebble-watchface-halftone/resources/fonts" / name, OUT / "fonts" / name)
for name in ["generate-artwork.py", "verify-icons.py", "capture-halftone-orange.py", "update-website.py", "review-previews.py", "assemble-update.py", "package-artwork.py", "research.json", "live-store.json", "store-commits.json", "banners-contact-sheet.png", "banners-contact-sheet.svg", "icons-light-dark.png", "icons-light-dark.svg"]:
    copy(ROOT / name, OUT / name)
releases = json.loads((WATCH / "Pebble-Store-Versions-2026-11-14/products.json").read_text())
for release, product in zip(releases, ["dynamic", "halftone", "timer", "dashboard", "open-activity", "chmu-weather"]):
    store = WATCH / release["repo"] / "store"
    art = json.loads((store / "artwork-provenance.json").read_text())
    for banner in art["banners"].values():
        if "screenshot" in banner:
            copy(store / banner["screenshot"], OUT / "products" / product / banner["screenshot"])
    for name in ["orange-capture-provenance.json", "capture-provenance.json"]:
        if (store / name).exists():
            copy(store / name, OUT / "products" / product / name)
browser = SITE / "build/qa/pebble-artwork-20261114"
report = json.loads((browser / "report.json").read_text())
assert report["passed"] is True
for name in ["report.json", "weather-glyph-light.png", "weather-glyph-dark.png", "home-1440-light.png", "home-390-first-screen.png", "halftone-round2-dark-no-javascript.png"]:
    copy(browser / name, ROOT / "verification/website" / name)
    copy(browser / name, OUT / "verification/website" / name)
for name, source in [("site-tests.log", "/tmp/xoce-pebble-artwork-site-tests.log"), ("deployment-check.log", "/tmp/xoce-pebble-artwork-deployment-check.log"), ("browser.log", "/tmp/xoce-pebble-artwork-browser.log")]:
    copy(Path(source), ROOT / "verification/website" / name)
    copy(Path(source), OUT / "verification/website" / name)
(OUT / "README.md").write_text("""# XOCE Store artwork — original Halftone direction

Selected on 14 November 2026: bold colour fields, curved patterned edges, large outlined Fira Sans Condensed titles and generic illustrated watches. `reference/` preserves Xef's original orange Halftone banner. Screens in the banners are original native PNGs; the two orange Halftone captures are fresh QEMU results of the checked 1.10.2 renderer.

`products/` contains editable SVGs and deterministic exports. Store banners are 720×320; standalone screenshots remain unframed at native resolution. Weather's phone banner is website artwork, not a Store upload field.

The four Store icon sets are transparent black binary glyphs at 80×80 and 144×144. Enable `icon_tintable=true` in Developer Dashboard, then verify it through the public API and inspect light/dark mode. The local listing JSON does not change the live flag. The exact signed-in control label has not been verified. The API documentation is linked in `research.json`.

Fira Sans Condensed Bold is included with SIL OFL 1.1 in `fonts/`. Each product includes `ARTWORK-LICENSES.txt`; app licence notices stay separate in the complete Store handoff. These are adaptations of the original XOCE banner and original pixel glyphs, with no external watch-frame photograph in the Store banners.

The Python recipes document generation within the XOCE workspace using fontTools, Pillow and rsvg-convert. `generate-artwork.py` reads the app Store screenshot files and font input; `--apply` copies selected output to the app repos. `verify-icons.py` checks dimensions, pure black pixels, binary alpha and transparent margins, including deliberate invalid fixtures. `review-previews.py` makes contact sheets from actual exports. Native capture requires the isolated SDK 4.44 environment documented by the capture script.

`verification/` records fresh six-app tests/Store checks, icon validation, two Halftone emulator captures and the website browser suite (14 checks, 160 screenshots; selected proof included). No physical-device test or remote Store change is claimed. Frozen PBWs are in the complete Store handoff, not this artwork source ZIP. Rejected experiments and emulator state are excluded.
""")
files = sorted(p for p in OUT.rglob("*") if p.is_file())
assert not any(p.suffix == ".pbw" for p in files)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
(OUT / "SHA256SUMS.txt").write_text("".join(f"{digest(p)}  {p.relative_to(OUT).as_posix()}\n" for p in files))
archive = ROOT / "XOCE-Pebble-Store-Artwork-2026-11-14.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(OUT.rglob("*")):
        if p.is_file():
            z.write(p, "XOCE-Pebble-Store-Artwork-2026-11-14/" + p.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
(ROOT / (archive.name + ".sha256")).write_text(digest(archive) + "  " + archive.name + "\n")
print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size, "sha256": digest(archive)}, indent=2))
