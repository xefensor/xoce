# XOCE Store artwork — original Halftone direction

Selected on 14 November 2026: bold colour fields, curved patterned edges, large outlined Fira Sans Condensed titles and generic illustrated watches. `reference/` preserves Xef's original orange Halftone banner. Screens in the banners are original native PNGs; the two orange Halftone captures are fresh QEMU results of the checked 1.10.2 renderer.

`products/` contains editable SVGs and deterministic exports. Store banners are 720×320; standalone screenshots remain unframed at native resolution. Weather's phone banner is website artwork, not a Store upload field.

The four Store icon sets are transparent black binary glyphs at 80×80 and 144×144. Enable `icon_tintable=true` in Developer Dashboard, then verify it through the public API and inspect light/dark mode. The local listing JSON does not change the live flag. The exact signed-in control label has not been verified. The API documentation is linked in `research.json`.

Fira Sans Condensed Bold is included with SIL OFL 1.1 in `fonts/`. Each product includes `ARTWORK-LICENSES.txt`; app licence notices stay separate in the complete Store handoff. These are adaptations of the original XOCE banner and original pixel glyphs, with no external watch-frame photograph in the Store banners.

The Python recipes document generation within the XOCE workspace using fontTools, Pillow and rsvg-convert. `generate-artwork.py` reads the app Store screenshot files and font input; `--apply` copies selected output to the app repos. `verify-icons.py` checks dimensions, pure black pixels, binary alpha and transparent margins, including deliberate invalid fixtures. `review-previews.py` makes contact sheets from actual exports. Native capture requires the isolated SDK 4.44 environment documented by the capture script.

`verification/` records fresh six-app tests/Store checks, icon validation, two Halftone emulator captures and the website browser suite (14 checks, 160 screenshots; selected proof included). No physical-device test or remote Store change is claimed. Frozen PBWs are in the complete Store handoff, not this artwork source ZIP. Rejected experiments and emulator state are excluded.
