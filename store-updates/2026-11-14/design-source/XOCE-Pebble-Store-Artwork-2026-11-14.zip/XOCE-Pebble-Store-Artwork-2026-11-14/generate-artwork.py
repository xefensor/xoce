"""Original-Halftone-style Store banners and transparent tintable glyphs.

Generate into this review folder first. --apply copies the reviewed outputs to
the app Store directories, leaving native captures and frozen releases intact.
"""
from pathlib import Path
import argparse
import base64
import hashlib
import html
import json
import subprocess
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen

REVIEW = Path(__file__).resolve().parent
WATCH = REVIEW.parent
parser = argparse.ArgumentParser()
parser.add_argument("--product", choices=["all", "dynamic", "halftone", "timer", "dashboard", "open-activity", "chmu-weather"], default="all")
parser.add_argument("--apply", action="store_true")
args = parser.parse_args()
PRODUCTS = [
    ("dynamic", "pebble-watchface-dynamic", "Dynamic", ["Your clock.", "Your readings."]),
    ("halftone", "pebble-watchface-halftone", "Halftone", ["A bold clock.", "A border of dots."]),
    ("timer", "pebble-app-timer", "Timer", ["Set it. Start it.", "Use it again."]),
    ("dashboard", "pebble-app-dashboard", "Dashboard", ["Your overview.", "One button away."]),
    ("open-activity", "pebble-app-open-activity", "Open Activity", ["A quick shortcut", "back to the app."]),
    ("chmu-weather", "pebble-chmu-weather", "ČHMÚ Weather", ["Czech weather.", "In your Pebble app."]),
]
FONT_PATH = WATCH / "pebble-watchface-halftone/resources/fonts/FiraSansCondensed-Bold.ttf"
font = TTFont(FONT_PATH)
ACCENTS={"dynamic":"#0055ff","halftone":"#ff5500","timer":"#5555ff","dashboard":"#00aa55","open-activity":"#aa55ff","chmu-weather":"#0055ff"}
TAGLINES={"dynamic":"YOUR CLOCK. YOUR READINGS.","halftone":"DITHERED INTO THE BEZEL","timer":"SET IT. KEEP IT READY.","dashboard":"YOUR OVERVIEW, ONE PRESS AWAY","open-activity":"ONE SHORTCUT BACK TO THE APP","chmu-weather":"CZECH WEATHER FOR YOUR PEBBLE"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def text(value, x, y, size, fill="#000", tracking=0):
    glyphs = font.getGlyphSet()
    cmap = font.getBestCmap()
    parts, advance = [], 0
    for char in value:
        name = cmap[ord(char)]
        pen = SVGPathPen(glyphs)
        glyphs[name].draw(pen)
        if pen.getCommands():
            parts.append(f'<path transform="translate({advance},0)" d="{pen.getCommands()}"/>')
        advance += font["hmtx"][name][0] + tracking * font["head"].unitsPerEm / size
    scale = size / font["head"].unitsPerEm
    return f'<g aria-label="{html.escape(value)}" fill="{fill}" transform="translate({x},{y}) scale({scale},-{scale})">'+"".join(parts)+"</g>"


def measure(value,size,tracking=0):
    cmap=font.getBestCmap()
    return sum(font['hmtx'][cmap[ord(c)]][0]for c in value)*size/font['head'].unitsPerEm+max(0,len(value)-1)*tracking


def svg(body, width, height, title):
    return f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img"><title>{html.escape(title)}</title>{body}</svg>\n'


def glyph(slug):
    pixels = set()

    def rect(x, y, w=1, h=1):
        pixels.update((a,b) for a in range(x,x+w) for b in range(y,y+h))

    def outline(x, y, w, h):
        rect(x,y,w);rect(x,y+h-1,w);rect(x,y,1,h);rect(x+w-1,y,1,h)

    if slug == "timer":
        rect(2,2,12);rect(2,13,12)
        for y,x in [(3,3),(4,3),(5,4),(6,5),(7,6),(8,6),(9,5),(10,4),(11,3),(12,3)]:
            rect(x,y);rect(15-x,y)
        rect(5,4,6);rect(6,5,4);rect(7,6,2)
        rect(7,10,2);rect(6,11,4);rect(5,12,6)
    elif slug == "dashboard":
        rect(2,2,5,5);outline(9,2,5,5);outline(2,9,5,5);outline(9,9,5,5)
    elif slug == "open-activity":
        rect(2,3,1,10);rect(2,3,4);rect(2,12,4)
        rect(6,7,8,2)
        for x,y in [(9,3),(10,4),(11,5),(12,6),(12,9),(11,10),(10,11),(9,12)]:
            rect(x,y,2)
    elif slug == "chmu-weather":
        rect(3,3,4,4);rect(4,1,2);rect(1,4,1,2);rect(2,2);rect(8,2)
        rect(6,5,5);rect(5,6,7);rect(3,7,10);rect(2,8,12,3);rect(3,11,10)
        rect(4,13,1,2);rect(8,13,1,2);rect(12,13,1,2)
    elif slug == "dynamic":
        outline(1,1,14,14)
        rect(4,4,1,5);rect(3,5);rect(8,4,4);rect(10,5);rect(9,6,2);rect(10,7);rect(8,8,4)
        for x in [4,9]:
            rect(x,11,2);rect(x,13,2)
    else:
        ring = [(6,1),(9,1),(3,2),(12,2),(2,4),(13,4),(1,7),(14,7),(2,10),(13,10),(3,12),(12,12),(6,14),(9,14)]
        for x,y in ring:rect(x,y)
        rect(5,5,1,6);rect(4,6);rect(8,5,4);rect(11,6,1,2);rect(9,8,3);rect(8,9);rect(8,10,4)
    assert all(0<=x<16 and 0<=y<16 for x,y in pixels)
    paths=[]
    for y in range(16):
        x=0
        while x<16:
            if (x,y) not in pixels:
                x+=1;continue
            end=x+1
            while (end,y) in pixels:end+=1
            paths.append(f'M{x} {y}h{end-x}v1H{x}z');x=end
    return '<path fill="currentColor" d="'+"".join(paths)+'"/>'


def image(path, x, y, w, h, extra=""):
    encoded = base64.b64encode(path.read_bytes()).decode()
    return f'<image x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="xMidYMid meet" style="image-rendering:pixelated" {extra} xlink:href="data:image/png;base64,{encoded}"/>'


def banner_base(slug,name,platform):
    accent=ACCENTS[slug]
    pattern=(f'<circle cx="4" cy="4" r="3" fill="{accent}" opacity=".48"/><circle cx="12" cy="12" r="1.7" fill="{accent}" opacity=".28"/>'if slug=='halftone'else f'<g transform="translate(4 4) scale(.75)" color="{accent}" opacity=".35" shape-rendering="crispEdges">{glyph(slug)}</g>')
    period=16 if slug=='halftone'else 26
    body=f'<defs><linearGradient id="background" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#08090b"/><stop offset="1" stop-color="#202126"/></linearGradient><linearGradient id="metal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#e1e2e5"/><stop offset=".45" stop-color="#76797f"/><stop offset="1" stop-color="#c8c9cc"/></linearGradient><pattern id="motif" width="{period}" height="{period}" patternUnits="userSpaceOnUse">{pattern}</pattern></defs>'
    body+='<rect width="720" height="320" fill="url(#background)"/>'
    body+=f'<path d="M0 0H355C310 60 315 126 350 174C376 209 364 270 318 320H0Z" fill="{accent}"/>'
    body+='<path d="M306 0H420V320H278C337 261 337 207 306 164C271 116 269 60 306 0Z" fill="url(#motif)"/>'
    size=68
    while measure(name.upper(),size,2)>360:size-=1
    body+=text(name.upper(),42,129,size,'#ffffff',2)
    size=24
    while measure(TAGLINES[slug],size)>302:size-=1
    assert size>=20,(slug,'Subtitle too small')
    body+=text(TAGLINES[slug],44,171,size,'#101114')
    device='Pebble Time 2'if platform=='emery'else'Pebble Round 2'if platform=='gabbro'else'the Pebble phone app'
    body+=text('Made for '+device,44,229,20,'#ffffff')
    return body


def watch(body,platform,screen):
    body+='<rect x="493" y="1" width="146" height="22" rx="8" fill="#8b8d91"/><rect x="493" y="297" width="146" height="22" rx="8" fill="#8b8d91"/>'
    if platform=='emery':
        body+='<rect x="443" y="12" width="246" height="296" rx="50" fill="url(#metal)" stroke="#f4f4f5" stroke-width="2"/><rect x="454" y="28" width="224" height="264" rx="42" fill="#050505"/><defs><clipPath id="screen"><rect x="466" y="46" width="200" height="228" rx="30"/></clipPath></defs>'
        body+=image(screen,466,46,200,228,'clip-path="url(#screen)"')
    else:
        body+='<circle cx="566" cy="160" r="146" fill="url(#metal)" stroke="#f4f4f5" stroke-width="2"/><circle cx="566" cy="160" r="135" fill="#050505"/><defs><clipPath id="screen"><circle cx="566" cy="160" r="130"/></clipPath></defs>'
        body+=image(screen,436,30,260,260,'clip-path="url(#screen)"')
    return body


for slug, repo_name, name, benefit in PRODUCTS:
    if args.product not in ("all",slug):continue
    store=WATCH/repo_name/"store"
    target=REVIEW/"products"/slug
    target.mkdir(parents=True,exist_ok=True)
    listing=json.loads((store/"listing.json").read_text())
    files={}

    def write(name, content):
        (target/name).write_text(content)
        files[name]=sha((target/name).read_bytes())

    def render(source, destination, size=None):
        command=["rsvg-convert",str(target/source),"-o",str(target/destination)]
        if size:command += ["-w",str(size),"-h",str(size)]
        subprocess.run(command,check=True)
        files[destination]=sha((target/destination).read_bytes())

    shape=glyph(slug)
    icon=f'<svg xmlns="http://www.w3.org/2000/svg" width="144" height="144" viewBox="0 0 16 16" shape-rendering="crispEdges" color="#000" role="img"><title>{html.escape(name)} transparent monochrome glyph</title>{shape}</svg>\n'
    write("product-mark.svg",icon);render("product-mark.svg","product-mark-144.png")
    if listing["type"] != "watchface":
        write("icon-source.svg",icon);render("icon-source.svg","icon-small-80.png",80);render("icon-source.svg","icon-large-144.png",144)
        listing["icon_tintable"]=True
        (target/"icon-provenance.json").write_text(json.dumps({"schemaVersion":1,"originalArtwork":True,"family":"XOCE Pebble glyphs 2026-11-14","icon_tintable":True,"ink":"#000000","background":"transparent","alphaValues":[0,255],"pixelGrid":[16,16],"format":"8-bit RGBA PNG containing a single-colour binary glyph; no antialiasing, gradients, shadows or background plate.","source":"https://appstore-api.repebble.com/#changelog","files":{key:files[key]for key in ["icon-source.svg","icon-small-80.png","icon-large-144.png"]}},indent=2)+"\n")
    banners={}
    if listing["type"] != "plugin":
        for platform,names in listing["screenshots"].items():
            screen_name=next((n for n in names if "orange" in n),next((n for n in names if "four-split" in n),names[0]))
            screen=store/screen_name
            body=watch(banner_base(slug,name,platform),platform,screen)
            source=platform+"-family-banner.svg";png=source.replace(".svg",".png")
            write(source,svg(body,720,320,name+" · "+platform+" · original native pixels"));render(source,png)
            banners[platform]={"file":png,"platform":platform,"screenshot":screen_name,"screenshotSha256":sha(screen.read_bytes()),"composition":"Based on Xef's original Halftone banner: bold colour field, curved patterned edge and illustrated watch. Native display stays at 1:1; original embedded capture bytes unchanged.","illustrationSource":"pebble-watchface-halftone/store/banner-source.svg"}
        listing["banners"]={key:record["file"]for key,record in banners.items()}
    else:
        # Website share image only; plugins have no Store banner field.
        body=banner_base(slug,name,'phone')
        body+=f'<g transform="translate(470 64) scale(12)" color="#ffffff" shape-rendering="crispEdges">{shape}</g>'
        write("website-banner.svg",svg(body,720,320,name+" · phone plugin · website-only"));render("website-banner.svg","website-banner.png")
    notices=(WATCH/"XOCE-Identity-2026-11-14/fonts/source/OFL.txt").read_text()
    (target/"ARTWORK-LICENSES.txt").write_text("Original XOCE composition and monochrome glyphs, prepared for Xef.\nThe campaign layout and watch illustration adapt Xef's original Halftone banner-source.svg; its app repository licensing remains authoritative.\nNative emulator PNG bytes are unchanged; synthetic example data. The orange Halftone captures have fresh SDK 4.44 emulator evidence; no physical-device claim.\nNo third-party watch photo, Core Devices frame image or borrowed logo is used in this new banner set.\nFira Sans Condensed text is outlined from the app's font; SIL OFL 1.1 follows.\n\n"+notices)
    artwork={"schemaVersion":1,"originalArtwork":True,"family":"XOCE original-Halftone Store family 2026-11-14","scope":"Xef selected the original orange Halftone banner as the reference: bold colour, curved patterned edge, large title and illustrated watch. Original binary glyphs use transparency and icon_tintable; native screenshot PNGs remain unchanged.","font":{"name":"Fira Sans Condensed Bold","licence":"SIL OFL 1.1","sourceSha256":sha(FONT_PATH.read_bytes()),"treatment":"Outlined SVG text"},"reference":{"file":"pebble-watchface-halftone/store/halftone-banner-720x320.png","sha256":sha((WATCH/'pebble-watchface-halftone/store/halftone-banner-720x320.png').read_bytes())},"files":{key:value for key,value in files.items()if not key.startswith("website-banner")},"banners":banners}
    (target/"artwork-provenance.json").write_text(json.dumps(artwork,ensure_ascii=False,indent=2)+"\n")
    (target/"listing.json").write_text(json.dumps(listing,ensure_ascii=False,indent=2)+"\n")
    if args.apply:
        import shutil
        for file in target.iterdir():
            if file.is_file() and not file.name.startswith("website-banner"):
                shutil.copyfile(file,store/file.name)
    print(name,"exported", "and applied" if args.apply else "for preview",flush=True)
